from project.player import Player
from project.supply.food import Food
from project.supply.supply import Supply


class Controller:
    def __init__(self):
        self.players = []
        self.supplies = []
        self.player_names = set()

    def __search_for_food(self):
        food = [f for f in self.supplies if f.__class__.__name__ == 'Food']
        return food if food else None

    def __search_for_drink(self):
        drink = [f for f in self.supplies if f.__class__.__name__ == 'Drink']
        return drink if drink else None

    def __search_player_by_name(self, player_name):
        player = [p for p in self.players if p.name == player_name]
        return player[0] if player else None

    # TODO
    def add_player(self, *args: Player):
        result = []
        for player in args:
            if player.name not in self.player_names:
                self.players.append(player)
                self.player_names.add(player.name)
                result.append(player.name)
        return f"Successfully added: {', '.join(result)}"

    def add_supply(self, *args: Supply):
        for supply in args:
            self.supplies.append(supply)

    def sustain(self, player_name, sustenance_type):
        food = self.__search_for_food()
        drink = self.__search_for_drink()
        player = self.__search_player_by_name(player_name)

        if player.stamina == 100:
            return f"{player_name} have enough stamina."

        if sustenance_type == 'Food':
            if food is None:
                raise Exception("There are no food supplies left!")
            last_food = food[-1]
            player.stamina += last_food.energy
            self.supplies.remove(last_food)
            return f"{player_name} sustained successfully with {last_food.name}."
        if sustenance_type == 'Drink':
            if drink is None:
                raise Exception("There are no drink supplies left!")
            last_drink = drink[-1]
            player.stamina += last_drink.energy
            self.supplies.remove(last_drink)
            return f"{player_name} sustained successfully with {last_drink.name}."

        if player.stamina > 100:
            player.stamina = 100

    def duel(self, first_player_name, second_player_name):
        if first_player_name == second_player_name:
            raise Exception(f"Name {first_player_name} is already used!")
        first_player = self.__search_player_by_name(first_player_name)
        second_player = self.__search_player_by_name(second_player_name)

        if first_player.stamina == 0 and second_player.stamina == 0:
            return f"Player {first_player_name} does not have enough stamina.\n" \
                   f"Player {second_player_name} does not have enough stamina."
        if first_player.stamina == 0:
            return f"Player {first_player_name} does not have enough stamina."
        if second_player.stamina == 0:
            return f"Player {second_player_name} does not have enough stamina."
        player_with_more_health = 0
        player_with_less_health = 0
        winner = 0
        if first_player.stamina > second_player.stamina:
            player_with_more_health = first_player
            player_with_less_health = second_player
        else:
            player_with_more_health = second_player
            player_with_less_health = first_player

        player_with_more_health.stamina -= (player_with_less_health.stamina / 2)
        if player_with_more_health.stamina <= 0:
            player_with_more_health.stamina = 0
            winner = player_with_less_health.name
            return f"Winner: {winner}"

        player_with_less_health.stamina -= (player_with_more_health.stamina / 2)
        if player_with_less_health.stamina <= 0:
            player_with_less_health.stamina = 0
            winner = player_with_more_health.name
            return f"Winner: {winner}"

        if player_with_more_health.stamina > player_with_less_health.stamina:
            return f"Winner: {player_with_more_health.name}"
        else:
            return f"Winner: {player_with_less_health.name}"

    def next_day(self):
        food = self.__search_for_food()
        drink = self.__search_for_drink()

        for player in self.players:
            result = player.age * 2

            if player.stamina - result < 0:
                player.stamina = 0
            else:
                player.stamina -= result
            player.stamina += food[0].energy
            player.stamina += drink[1].energy
